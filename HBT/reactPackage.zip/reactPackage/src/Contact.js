import React from "react";

const Contact = () =>{
    return (
        <h1>
            Contact me at +123 456 7891.
        </h1>
    )
}

export default Contact