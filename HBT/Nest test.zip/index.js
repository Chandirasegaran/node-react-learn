require('@babel/register');
require('./src/main');
