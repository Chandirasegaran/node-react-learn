// src/mongo.config.js

module.exports = {
    url: 'mongodb+srv://Parkavi:iZJNOONrBjsXVjZL@cluster0.wad8pdy.mongodb.net/?retryWrites=true&w=majority', // MongoDB connection URL
    dbName: 'test', // Database name
  };
  